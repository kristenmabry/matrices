#ifndef CSM_HEADER
#define CSM_HEADER 
class CSquareMatrix
{
public:
	CSquareMatrix(const CSquareMatrix& other);
	CSquareMatrix(int dimension);	
	CSquareMatrix(int dimension, int num); 
	~CSquareMatrix();

	CSquareMatrix& operator=(const CSquareMatrix& rhs);	
	friend bool operator==(const CSquareMatrix& lhs, const CSquareMatrix& rhs);	
	friend std::ostream& operator<<(std::ostream& outStream, const CSquareMatrix& disp);

	double** GetMatrix() { return m_matrix; }
	int  GetDimension() { return m_dimension; }

private:
	int m_dimension;
	double** m_matrix;

};

double Determinant(double** matrix, int dim);
double Gaussian(double** array, int dim);
void AddRow(double** array, int dim, int src, int dest, long mult);

#endif
