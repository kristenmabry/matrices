#include <iostream>
#include <chrono>
#include <ctime>
#include "csquarematrix.h"
using namespace std;


int main()
{
	srand ( time(NULL) );
	int dim;
	cout << "Dimension: ";
	cin >> dim;
	CSquareMatrix m1(dim);

	cout << m1 << endl;

	auto start1 = chrono::high_resolution_clock::now();
	cout << Gaussian(m1.GetMatrix(), m1.GetDimension()) << endl;
	//cout << m1 << endl;
	auto end1 = chrono::high_resolution_clock::now();
	chrono::duration<double, milli> elapsed1 = end1 - start1;
	cout << elapsed1.count() << " ms" << endl;

	return 1;
}
