#include <iostream>
#include <cmath>
#include <cstdlib>
#include "csquarematrix.h"
using namespace std;

	CSquareMatrix::CSquareMatrix(int dimension)
{
	m_dimension = dimension;
	m_matrix = new double*[m_dimension];
	for (int i = 0; i < m_dimension; i++)
		{
		m_matrix[i] = new double[m_dimension];
		for (int j = 0; j < m_dimension; j++)
			{
			int value;
			//cout << "Set value " << i+1 << ", " << j+1 << ": ";
			//cin >> value;
			//m_matrix[i][j] = value;
			m_matrix[i][j] = static_cast<double>(rand() % 10) + 1.0;
			}
		}
}

	CSquareMatrix::CSquareMatrix(int dimension, int num)
{
	m_dimension = dimension;
	m_matrix = new double*[m_dimension];
	for (int i = 0; i < m_dimension; i++)
		{
		m_matrix[i] = new double[m_dimension];
		for (int j = 0; j < m_dimension; j++)
			{
			m_matrix[i][j] = num;
			}
		}

}

	CSquareMatrix::CSquareMatrix(const CSquareMatrix& other)
{
	m_dimension = other.m_dimension;
	m_matrix = new double*[m_dimension];
	for (int i = 0; i < m_dimension; i++)
		{
		m_matrix[i] = new double[m_dimension];
		for (int j = 0; j < m_dimension; j++)
			{
			m_matrix[i][j] = other.m_matrix[i][j];
			}
		}

}

	CSquareMatrix::~CSquareMatrix()
{
	for (int i = 0; i < m_dimension; i++)
		{
		delete[] m_matrix[i];
		}
	delete[] m_matrix;
}


CSquareMatrix& CSquareMatrix::operator=(const CSquareMatrix& rhs)
{
	if (this != &rhs)
		{
		if (m_dimension != rhs.m_dimension)
			{
			for (int i = 0; i < m_dimension; i++)
				{
				delete m_matrix[i];
				}
			delete m_matrix;
			}
		else
			{
			m_dimension = rhs.m_dimension;
			m_matrix = new double*[m_dimension];
			for (int i = 0; i < m_dimension; i++)
				{
				m_matrix[i] = new double[m_dimension];
				}
			}
		for (int i = 0; i < m_dimension; i++)
			{
			for (int j = 0; j < m_dimension; j++)
				{
				m_matrix[i][j] = rhs.m_matrix[i][j];
				}
			}
		}
	return *this;
}



bool operator==(const CSquareMatrix& lhs, const CSquareMatrix& rhs)
{
	if (&lhs == &rhs)
		{
		return true;
		}
	else if (lhs.m_dimension != rhs.m_dimension)
		{
		return false;
		}
	else
		{
		for (int i = 0; i < lhs.m_dimension; i++)
			{
			for (int j = 0; j < lhs.m_dimension; j++)
				{
				if ( lhs.m_matrix[i][j] != rhs.m_matrix[i][j] )
					{
					return false;
					}
				}
			}
		}
	return true;
}

ostream& operator<<(ostream& outStream, const CSquareMatrix& disp)
{
	for (int i = 0; i < disp.m_dimension; i++)
		{
		for (int j = 0; j < disp.m_dimension; j++)
			{
			outStream << disp.m_matrix[i][j] << " ";
			}
		outStream << endl;
		}
	return outStream;
}


double Determinant(double** matrix, int dim)
{
	if (dim == 2)
		{
		double det = (matrix[0][0] * matrix[1][1]) - (matrix[0][1] * matrix[1][0]);
		return det;
		}
	else
		{
		double det = 0;
		for (int i = 0; i < dim; i++)
			{
			double** newArray = new double*[dim-1];
			for (int k = 1; k < dim; k++)
				{
				int sub = 0;
				newArray[k-1] = new double[dim-1];
				for (int j = 0; j < dim; j++)
					{
					if (j == i)
						{
						sub++;
						}
					else
						{
						newArray[k-1][j-sub] = matrix[k][j];
						}
					}
				}
			det += pow(-1, i) * matrix[0][i] * Determinant(newArray, dim-1);

			for (int k = 0; k < dim-1; k++)
				{
				delete[] newArray[k];
				}
			delete[] newArray;
			}
		return det;
		}
}



void AddRow(double** array, int dim, int src, int dest, double mult)
{
	for (int i = 0; i < dim; i++)
		{	
		array[dest][i] += array[src][i] * mult;
		}
}


double Gaussian(double** array, int dim)
{
	for (int col = 0; col < dim-1; col++)
		{
		for (int row = col+1; row < dim; row++)
			{
			if (array[row][col])
				{
				double cancel = -array[row][col];
				double multiplier = cancel;
				multiplier /= array[col][col];
				AddRow(array, dim, col, row, multiplier);
				}
			}
		}
	double det = 1.0;
	for (int i = 0; i < dim; i++)
		{
		det *= array[i][i];
		}
	return det;
}
